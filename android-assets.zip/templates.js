(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/account-header/account-header.html',
    '<div class="header account-header">\n' +
    '	<i class="fa fa-bars" ng-click="headerCtrl.onToggleSidebar()"></i>\n' +
    '	<span ng-transclude></span>\n' +
    '\n' +
    '	<div class="filter-menu-toggle" ng-click="headerCtrl.onToggleFilterMenu()">\n' +
    '		<i class="fa" ng-class="{ \'fa-chevron-down\': !headerCtrl.showFilterMenu, \'fa-chevron-left\': headerCtrl.showFilterMenu }"></i>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/account-view/account-view.html',
    '<div class="account-view">\n' +
    '	<account-header show-sidebar="accountCtrl.showSidebar" show-filter-menu="accountCtrl.showFilterMenu">\n' +
    '		{{ accountCtrl.selectedAccount.name }}\n' +
    '	</account-header>\n' +
    '\n' +
    '	<app-sidebar show="accountCtrl.showSidebar"></app-sidebar>\n' +
    '\n' +
    '	<div class="expense-filter foldout-animation" ng-show="accountCtrl.showFilterMenu">\n' +
    '		<account-dropdown ng-model="accountCtrl.selectedAccount"></account-dropdown>\n' +
    '		<search-filter ng-model="accountCtrl.expenses" keys="accountCtrl.SEARCH_KEYS" on-change="accountCtrl.onSearchFilterChange(dstModel)"></search-filter>\n' +
    '		<category-filter ng-model="accountCtrl.expenses" on-change="accountCtrl.onCategoryFilterChange(dstModel)"></category-filter>\n' +
    '	</div>\n' +
    '\n' +
    '	<balance-block\n' +
    '			ng-repeat="balance in accountCtrl.balances"\n' +
    '			ng-model="balance"\n' +
    '			expenses="accountCtrl.filteredExpenses"\n' +
    '			open-on-init="$index < accountCtrl.MAX_OPEN_ON_START"\n' +
    '			is-last="$last"\n' +
    '	></balance-block>\n' +
    '\n' +
    '	<div class="footer">\n' +
    '		<add-data-button></add-data-button>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/analysis-block/analysis-block.html',
    '<div class="analysis-block">\n' +
    '	<div class="analysis-block-header" ng-click="analysisCtrl.onContentToggle()">\n' +
    '		Analysis\n' +
    '\n' +
    '		<div class="analysis-block-toggle">\n' +
    '			<i class="fa" ng-class="{ \'fa-chevron-down\': !analysisCtrl.showContent, \'fa-chevron-left\': analysisCtrl.showContent }"></i>\n' +
    '		</div>\n' +
    '	</div>\n' +
    '\n' +
    '	<div class="analysis-block-content foldout-animation" ng-if="analysisCtrl.showContent">\n' +
    '		<date-block-option\n' +
    '				date-start="analysisCtrl.dateStart"\n' +
    '				date-end="analysisCtrl.dateEnd"\n' +
    '				on-change-start="analysisCtrl.filterExpenses()"\n' +
    '				on-change-end="analysisCtrl.filterExpenses()"\n' +
    '		></date-block-option>\n' +
    '\n' +
    '		<expense-analysis-chart expenses="analysisCtrl.filteredExpenses"></expense-analysis-chart>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/app-sidebar/app-sidebar.html',
    '<div class="app-sidebar" ng-show="sidebarCtrl.show">\n' +
    '	<div class="app-sidebar-content" ng-transclude>\n' +
    '		<div class="app-sidebar-item" ng-repeat="item in sidebarCtrl.items" ng-class="{ \'is-active\': sidebarCtrl.isActive(item) }" ng-click="sidebarCtrl.onItemClick(item)">{{ item.text }}</div>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/balance-block/balance-block.html',
    '<div class="balance-block">\n' +
    '	<div class="balance-block-header" ng-class="{ \'is-new\': blockCtrl.model.isNew }" on-long-click="blockCtrl.onEdit()" ng-click="blockCtrl.onContentToggle()">\n' +
    '		<div class="balance-block-title">\n' +
    '			<span ng-if="blockCtrl.model.date">{{blockCtrl.model.date | date }}</span>\n' +
    '			<span ng-if="!blockCtrl.model.date">Newest</span>\n' +
    '		</div>\n' +
    '\n' +
    '		<div class="balance-block-amount">\n' +
    '			<span ng-if="blockCtrl.model.amount">{{ blockCtrl.model.amount | number : 2 }} CHF</span>\n' +
    '		</div>\n' +
    '\n' +
    '		<div class="balance-block-toggle">\n' +
    '			<i class="fa" ng-class="{ \'fa-chevron-down\': !blockCtrl.showContent, \'fa-chevron-left\': blockCtrl.showContent }"></i>\n' +
    '		</div>\n' +
    '	</div>\n' +
    '\n' +
    '	<div class="balance-block-content foldout-animation" ng-if="blockCtrl.showContent">\n' +
    '		<balance-block-summary expenses="blockCtrl.filteredExpenses"></balance-block-summary>\n' +
    '\n' +
    '		<expense-item ng-repeat="expense in blockCtrl.filteredExpenses" ng-model="expense" is-last-block="blockCtrl.isLast"></expense-item>\n' +
    '\n' +
    '		<div ng-show="blockCtrl.filteredExpenses.length === 0" class="no-entry-message">\n' +
    '			No entries\n' +
    '		</div>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/expense-analysis-chart/expense-analysis-chart.html',
    '<!-- FIXME: legend plops in -->\n' +
    '<div class="expense-analysis-chart" id="expense-analysis-chart-{{ chartCtrl.id }}" ng-style="{ \'min-height\': chartCtrl.getChartHeight() }"></div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/expense-item/expense-item.html',
    '<div class="expense-item">\n' +
    '	<div class="expense-item-background">\n' +
    '		<div>\n' +
    '			<i class="fa fa-times"></i>\n' +
    '			Delete\n' +
    '		</div>\n' +
    '	</div>\n' +
    '	<div class="expense-item-body" on-long-click="expenseItemCtrl.onEdit()" on-swipe="expenseItemCtrl.accountCtrl.deleteExpense(expenseItemCtrl.model)" swipe-direction="right">\n' +
    '		<div class="expense-item-display" ng-class="{ \'is-new\': expenseItemCtrl.model.isNew }">\n' +
    '			<div class="expense-item-title">\n' +
    '				<i ng-if="expenseItemCtrl.model.category.icon" class="fa fa-{{expenseItemCtrl.model.category.icon}}"></i>\n' +
    '				{{ expenseItemCtrl.model.title }}\n' +
    '			</div>\n' +
    '			<div class="expense-item-amount">{{ expenseItemCtrl.model.amount | number }} CHF</div>\n' +
    '\n' +
    '			<div class="expense-item-toggle" ng-click="expenseItemCtrl.onToggleDetail()">\n' +
    '				<i class="fa" ng-class="{ \'fa-plus\': !expenseItemCtrl.showDetail, \'fa-minus\': expenseItemCtrl.showDetail }"></i>\n' +
    '			</div>\n' +
    '		</div>\n' +
    '\n' +
    '		<div class="expense-item-detail foldout-animation" target-height="450" ng-if="expenseItemCtrl.showDetail">\n' +
    '			<div class="expense-item-description" ng-if="expenseItemCtrl.model.description" ng-bind-html="expenseItemCtrl.displayDescription | html"></div>\n' +
    '\n' +
    '			<div class="kvp-table">\n' +
    '				<div>\n' +
    '					<div>Date</div>\n' +
    '					<div>{{ expenseItemCtrl.model.date | date }}</div>\n' +
    '				</div>\n' +
    '				<div>\n' +
    '					<div>Amount</div>\n' +
    '					<div>{{ expenseItemCtrl.model.amount | number }} CHF</div>\n' +
    '				</div>\n' +
    '				<div ng-if="expenseItemCtrl.model.category.name">\n' +
    '					<div>Category</div>\n' +
    '					<div>{{ expenseItemCtrl.model.category.name }}</div>\n' +
    '				</div>\n' +
    '			</div>\n' +
    '\n' +
    '			<expense-progress-chart ng-if="!expenseItemCtrl.isLastBlock" ng-model="expenseItemCtrl.model" balances="expenseItemCtrl.accountCtrl.balances" expenses="expenseItemCtrl.accountCtrl.expenses"></expense-progress-chart>\n' +
    '		</div>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/expense-progress-chart/expense-progress-chart.html',
    '<div class="expense-progress-chart">\n' +
    '	<div class="chart-wrapper">\n' +
    '		<div class="chart" ng-style="{ \'width\': chartCtrl.chartData.chartWidth }" id="{{ chartCtrl.id }}"></div>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/fullscreen-modal/fullscreen-modal.html',
    '<div class="modal-wrapper">\n' +
    '	<div class="modal-container">\n' +
    '		<div class="modal-body">\n' +
    '			<div class="modal-header" ng-if="modalCtrl.header">\n' +
    '				{{ modalCtrl.header }}\n' +
    '			</div>\n' +
    '\n' +
    '			<div class="modal-content animation-foldout-scroll-parent" ng-transclude></div>\n' +
    '\n' +
    '			<div class="modal-footer" ng-if="modalCtrl.buttons && modalCtrl.buttons.length > 0">\n' +
    '				<div class="modal-button" ng-repeat="button in modalCtrl.buttons" ng-class="{ \'primary-action\': button.isPrimary }" ng-click="modalCtrl.onButtonClick(button)">\n' +
    '					{{ button.text }}\n' +
    '					<i class="fa {{ button.icon }}"></i>\n' +
    '				</div>\n' +
    '			</div>\n' +
    '		</div>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/add-data/add-data-button/add-data-button.html',
    '<div class="add-expense-button" ng-click="buttonCtrl.onButtonClick()">\n' +
    '	<i class="fa fa-plus"></i>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/add-data/add-data-dialog/add-data-dialog.html',
    '<div class="add-data-dialog">\n' +
    '	<content-tabs tabs="addDataCtrl.tabs" ng-model="addDataCtrl.selectedTab"></content-tabs>\n' +
    '\n' +
    '	<expense-input-mask ng-if="addDataCtrl.selectedTab === addDataCtrl.tabs[0].value"></expense-input-mask>\n' +
    '	<balance-input-mask ng-if="addDataCtrl.selectedTab === addDataCtrl.tabs[1].value"></balance-input-mask>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/add-data/balance-input-mask/balance-input-mask.html',
    '<div class="balance-input-mask">\n' +
    '	<div class="balance-input-field amount">\n' +
    '		<number-input ng-model="inputMaskCtrl.amount" type="number" title="Amount"></number-input>\n' +
    '	</div>\n' +
    '\n' +
    '	<div class="balance-input-field date">\n' +
    '		<date-input ng-model="inputMaskCtrl.date" title="Date"></date-input>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/add-data/content-tabs/content-tabs.html',
    '<div class="content-tabs-container">\n' +
    '	<div class="content-tab" ng-repeat="tab in tabsCtrl.tabs" ng-class="{ \'is-selected\': tabsCtrl.model === tab.value }" ng-click="tabsCtrl.onTabSelect(tab)">\n' +
    '		{{ tab.text }}\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/add-data/expense-input-mask/expense-input-mask.html',
    '<div class="expense-input-mask">\n' +
    '	<div class="expense-input-field category">\n' +
    '		<dropdown-input ng-model="inputMaskCtrl.category" options="inputMaskCtrl.categories" render="inputMaskCtrl.renderCategory(option)" placeholder="-- Category --"></dropdown-input>\n' +
    '	</div>\n' +
    '\n' +
    '	<div class="expense-input-field title">\n' +
    '		<text-input ng-model="inputMaskCtrl.title" title="Title"></text-input>\n' +
    '	</div>\n' +
    '\n' +
    '	<div class="expense-input-field amount">\n' +
    '		<number-input ng-model="inputMaskCtrl.amount" title="Amount"></number-input>\n' +
    '	</div>\n' +
    '\n' +
    '	<div class="expense-input-field description">\n' +
    '		<text-input-box ng-model="inputMaskCtrl.description" rows="3" title="Description"></text-input-box>\n' +
    '	</div>\n' +
    '\n' +
    '	<div class="expense-input-field date">\n' +
    '		<date-input ng-model="inputMaskCtrl.date" title="Date"></date-input>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/analysis-block/date-block-option/date-block-option.html',
    '<div class="date-block-option">\n' +
    '	<date-input title="Start Date" ng-model="optionCtrl.dateStart"></date-input>\n' +
    '	<date-input title="End Date" ng-model="optionCtrl.dateEnd"></date-input>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/balance-block/balance-block-summary/balance-block-summary.html',
    '<div class="balance-block-summary" ng-if="summaryCtrl.expenses.length > 0">\n' +
    '	<div class="balance-block-summary-display" ng-click="summaryCtrl.onToggleContent()">\n' +
    '		<div class="balance-block-summary-title">\n' +
    '			Sum\n' +
    '		</div>\n' +
    '		<div class="balance-block-summary-amount">\n' +
    '			{{ summaryCtrl.expenseSum | number }} CHF\n' +
    '		</div>\n' +
    '		<div class="balance-block-summary-toggle">\n' +
    '			<i class="fa" ng-class="{ \'fa-chevron-left\': summaryCtrl.showContent, \'fa-chevron-down\': !summaryCtrl.showContent }"></i>\n' +
    '		</div>\n' +
    '	</div>\n' +
    '\n' +
    '	<div class="balance-block-summary-content foldout-animation" ng-if="summaryCtrl.showContent">\n' +
    '		<expense-analysis-chart expenses="summaryCtrl.expenses"></expense-analysis-chart>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/expense-filter/account-dropdown/account-dropdown.html',
    '<div class="account-dropdown" ng-if="accountDropdownCtrl.accounts.length > 1">\n' +
    '	<div class="account-dropdown-display" ng-click="accountDropdownCtrl.onFoldoutToggle()">\n' +
    '		<div class="account-dropdown-selection">\n' +
    '			{{ accountDropdownCtrl.model.name }}\n' +
    '		</div>\n' +
    '		\n' +
    '		<div class="account-dropdown-toggle">\n' +
    '			<i class="fa" ng-class="{ \'fa-chevron-down\': !accountDropdownCtrl.showFoldout, \'fa-chevron-left\': accountDropdownCtrl.showFoldout }"></i>\n' +
    '		</div>\n' +
    '	</div>\n' +
    '\n' +
    '	<div class="account-dropdown-foldout foldout-animation" ng-show="accountDropdownCtrl.showFoldout">\n' +
    '		<div class="account-dropdown-item" ng-repeat="account in accountDropdownCtrl.accounts" ng-click="accountDropdownCtrl.onAccountSelected(account)">\n' +
    '			{{ account.name }}\n' +
    '		</div>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/expense-filter/add-category-field/add-category-field.html',
    '<add-input-field on-submit="addCategoryCtrl.addCategory"></add-input-field>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/expense-filter/category-filter/category-filter.html',
    '<div class="category-filter">\n' +
    '	<category-filter-item  ng-repeat="category in categoryFilterCtrl.categories" ng-model="category"></category-filter-item>\n' +
    '\n' +
    '	<add-category-field></add-category-field>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/expense-filter/category-filter-item/category-filter-item.html',
    '<div class="category-filter-item" ng-class="{ \'selected\': itemCtrl.model.checked }" ng-click="itemCtrl.toggleCategory()" on-long-click="itemCtrl.onEdit()">\n' +
    '	<i ng-if="itemCtrl.model.icon" class="fa fa-{{itemCtrl.model.icon}}"></i>\n' +
    '	{{ itemCtrl.model.name }}\n' +
    '	<i class="fa" ng-class="{ \'fa-times\': !itemCtrl.model.checked, \'fa-check\': itemCtrl.model.checked }"></i>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/expense-filter/category-input-mask/category-input-mask.html',
    '<div class="category-input-mask">\n' +
    '	<div class="category-input-field name">\n' +
    '		<text-input ng-model="inputMaskCtrl.name" title="Name"></text-input>\n' +
    '	</div>\n' +
    '\n' +
    '	<div class="category-input-field icon">\n' +
    '		<icon-search ng-model="inputMaskCtrl.icon" on-select="inputMaskCtrl.onSelectIcon(icon)"></icon-search>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/expense-filter/icon-search/icon-search.html',
    '<div class="icon-search">\n' +
    '	<input-wrapper title="Icon" ng-model="iconSearchCtrl.model" >\n' +
    '		<input\n' +
    '				type="text"\n' +
    '				ng-model="inputCtrl.model"\n' +
    '				ng-disabled="false"\n' +
    '				ng-focus="inputCtrl.onFocus()"\n' +
    '				ng-blur="inputCtrl.onBlur()"\n' +
    '				ng-change="iconSearchCtrl.onChangeSearch(inputCtrl.model)"\n' +
    '		/>\n' +
    '	</input-wrapper>\n' +
    '\n' +
    '	<div class="icon-search-result-wrapper">\n' +
    '		<div class="icon-search-result" ng-repeat="icon in iconSearchCtrl.iconResults" ng-click="iconSearchCtrl.onSelect({ icon: icon })">\n' +
    '			<i class="fa fa-{{icon}}"></i>\n' +
    '		</div>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/expense-filter/search-filter/search-filter.html',
    '<div class="search-filter">\n' +
    '	<input type="text" ng-model="searchFilterCtrl.search" ng-change="searchFilterCtrl.performSearch()" ng-model-options="{ debounce: 500 }" />\n' +
    '	<i class="fa fa-times" ng-if="searchFilterCtrl.search" ng-click="searchFilterCtrl.clearSearch()"></i>\n' +
    '	<i class="fa fa-search"></i>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/input/add-input-field/add-input-field.html',
    '<div class="add-input-field">\n' +
    '	<input class="add-button-input" ng-if="inputCtrl.isOpen" ng-model="inputCtrl.model" ng-focus="inputCtrl.onFocusSelect()" />\n' +
    '	<i class="fa fa-plus" ng-click="inputCtrl.onClickPlus()"></i>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/input/date-input/date-input.html',
    '<div class="date-input">\n' +
    '	<div class="date-input-field" ng-click="dateInputCtrl.onToggleCalendar()" ng-class="{ focus: dateInputCtrl.showCalendar }">\n' +
    '		<text-input ng-model="dateInputCtrl.displayModel" ng-disabled="true" title="{{ dateInputCtrl.title }}"></text-input>\n' +
    '		<div class="date-input-button">\n' +
    '			<i class="fa fa-calendar"></i>\n' +
    '		</div>\n' +
    '	</div>\n' +
    '\n' +
    '	<div class="date-input-calendar foldout-animation" target-height="400" ng-if="dateInputCtrl.showCalendar">\n' +
    '		<date-picker ng-model="dateInputCtrl.model" ng-if="dateInputCtrl.showCalendar"></date-picker>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/input/dropdown-input/dropdown-input.html',
    '<div class="dropdown-input">\n' +
    '	<div class="dropdown-input-display" ng-class="{ \'dropdown-input-foldout-open\': inputCtrl.showFoldout }" ng-click="inputCtrl.onFoldoutToggle()">\n' +
    '		<div class="dropdown-input-selection" ng-bind-html="inputCtrl.renderOption(inputCtrl.model, true) | html"></div>\n' +
    '		\n' +
    '		<div class="dropdown-input-toggle">\n' +
    '			<i class="fa" ng-class="{ \'fa-chevron-down\': !inputCtrl.showFoldout, \'fa-chevron-left\': inputCtrl.showFoldout }"></i>\n' +
    '		</div>\n' +
    '	</div>\n' +
    '\n' +
    '	<div class="dropdown-input-foldout foldout-animation" ng-if="inputCtrl.showFoldout">\n' +
    '		<div class="dropdown-input-option" ng-repeat="option in inputCtrl.options" ng-click="inputCtrl.onOptionSelected(option)">\n' +
    '			<span ng-bind-html="::inputCtrl.renderOption(option, false) | html"></span>\n' +
    '		</div>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/input/generic-input/input-wrapper.html',
    '<div class="input-wrapper" ng-class="{ \'not-empty\': inputCtrl.model }">\n' +
    '	<div class="input-wrapper-title">{{ inputCtrl.title }}</div>\n' +
    '	<div class="input-wrapper-body" ng-transclude></div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/input/tag-input/tag-input.html',
    '<div class="input-wrapper" ng-class="{ \'not-empty\': inputCtrl.inputModel || inputCtrl.tags.length > 0 }" ng-click="inputCtrl.onFocus()">\n' +
    '	<div class="input-wrapper-title">{{ inputCtrl.title }}</div>\n' +
    '\n' +
    '	<div class="input-wrapper-body">\n' +
    '		<div class="tag-input" ng-class="{ \'has-tags\': inputCtrl.tags.length > 0 }">\n' +
    '			<div class="tag-list-item" ng-repeat="tag in inputCtrl.tags">\n' +
    '				{{ tag }}\n' +
    '				<i class="fa fa-times" ng-click="inputCtrl.onRemoveTag($index, $event)"></i>\n' +
    '			</div>\n' +
    '\n' +
    '			<input\n' +
    '				size="1"\n' +
    '				ng-disabled="inputCtrl.disabled"\n' +
    '				ng-model="inputCtrl.inputModel"\n' +
    '				ng-change="inputCtrl.onChange(inputCtrl.inputModel)"\n' +
    '				ng-trim="false"\n' +
    '				ng-blur="inputCtrl.onBlur()"\n' +
    '			/>\n' +
    '		</div>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/input/toggle-input/toggle-input.html',
    '<div class="toggle-input" ng-class="{ \'disabled\': inputCtrl.disabled }" ng-click="inputCtrl.onToggle()">\n' +
    '	<div class="toggle-input-toggler" ng-class="{ \'toggle-input-off\': inputCtrl.state === 0, \'toggle-input-on\': inputCtrl.state === 1 }"></div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/input/date-input/date-picker/date-picker.html',
    '<div class="date-picker-container">\n' +
    '	<div class="date-picker-header">\n' +
    '		<div class="date-picker-header-button" ng-click="dateCtrl.onPreviousYear()">\n' +
    '			<i class="fa fa-chevron-left"></i>\n' +
    '		</div>\n' +
    '		<div class="date-picker-header-title">\n' +
    '			{{ dateCtrl.year }}\n' +
    '		</div>\n' +
    '		<div class="date-picker-header-button" ng-click="dateCtrl.onNextYear()">\n' +
    '			<i class="fa fa-chevron-right"></i>\n' +
    '		</div>\n' +
    '	</div>\n' +
    '\n' +
    '	<div class="date-picker-table-container" on-swipe="dateCtrl.onSwipeMonth(direction)">\n' +
    '		<div class="date-picker-table-previous-month">\n' +
    '			<div class="date-picker-header">\n' +
    '				<div class="date-picker-header-title">{{ dateCtrl.monthNames[dateCtrl.previousMonth.month - 1] }}</div>\n' +
    '			</div>\n' +
    '\n' +
    '			<date-picker-table year="dateCtrl.previousMonth.year" month="dateCtrl.previousMonth.month"></date-picker-table>\n' +
    '		</div>\n' +
    '\n' +
    '		<div class="date-picker-table-current-month">\n' +
    '			<div class="date-picker-header">\n' +
    '				<div class="date-picker-header-button" ng-click="dateCtrl.onPreviousMonth()">\n' +
    '					<i class="fa fa-chevron-left"></i>\n' +
    '				</div>\n' +
    '				<div class="date-picker-header-title">\n' +
    '					{{ dateCtrl.monthNames[dateCtrl.month - 1] }}\n' +
    '				</div>\n' +
    '				<div class="date-picker-header-button" ng-click="dateCtrl.onNextMonth()">\n' +
    '					<i class="fa fa-chevron-right"></i>\n' +
    '				</div>\n' +
    '			</div>\n' +
    '\n' +
    '			<date-picker-table year="dateCtrl.year" month="dateCtrl.month" ng-model="dateCtrl.model"></date-picker-table>\n' +
    '		</div>\n' +
    '\n' +
    '		<div class="date-picker-table-next-month">\n' +
    '			<div class="date-picker-header">\n' +
    '				<div class="date-picker-header-title">{{ dateCtrl.monthNames[dateCtrl.nextMonth.month - 1] }}</div>\n' +
    '			</div>\n' +
    '\n' +
    '			<date-picker-table year="dateCtrl.nextMonth.year" month="dateCtrl.nextMonth.month" ng-model="dateCtrl.model"></date-picker-table>\n' +
    '		</div>\n' +
    '	</div>\n' +
    '</div>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/input/generic-input/number-input/number-input.html',
    '<input-wrapper title="{{ $ctrl.title }}" ng-model="$ctrl.model" ng-disabled="$ctrl.disabled">\n' +
    '	<input type="text" ng-model="inputCtrl.model" ng-disabled="inputCtrl.disabled" ng-focus="inputCtrl.onFocus()" ng-blur="inputCtrl.onBlur()" number-input-only />\n' +
    '</input-wrapper>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/input/generic-input/text-input/text-input.html',
    '<input-wrapper title="{{ $ctrl.title }}" ng-model="$ctrl.model" ng-disabled="$ctrl.disabled">\n' +
    '	<input type="text" ng-model="inputCtrl.model" ng-disabled="inputCtrl.disabled" ng-focus="inputCtrl.onFocus()" ng-blur="inputCtrl.onBlur()" />\n' +
    '</input-wrapper>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/input/generic-input/text-input-box/text-input-box.html',
    '<input-wrapper title="{{ $ctrl.title }}" ng-model="$ctrl.model" ng-disabled="$ctrl.disabled">\n' +
    '	<textarea rows="{{ $ctrl.rows }}" ng-model="inputCtrl.model" ng-disabled="inputCtrl.disabled" ng-focus="inputCtrl.onFocus()" ng-blur="inputCtrl.onBlur()"></textarea>\n' +
    '</input-wrapper>');
}]);
})();

(function(module) {
try {
  module = angular.module('app');
} catch (e) {
  module = angular.module('app', []);
}
module.run(['$templateCache', function($templateCache) {
  $templateCache.put('components/input/date-input/date-picker/date-picker-table/date-picker-table.html',
    '<table class="date-picker-table">\n' +
    '	<thead>\n' +
    '		<tr>\n' +
    '			<th ng-repeat="day in tableCtrl.calendarWeek">{{ day }}</th>\n' +
    '		</tr>\n' +
    '	</thead>\n' +
    '\n' +
    '	<tbody>\n' +
    '		<tr ng-repeat="week in tableCtrl.calendarMonth" ng-if="!$last || tableCtrl.hasRowDays(tableCtrl.year, tableCtrl.month, week)">\n' +
    '			<td ng-repeat="day in tableCtrl.calendarWeek" bind-value="date = tableCtrl.getDate(tableCtrl.year, tableCtrl.month, week, $index)" ng-class="{ \'prev-month\': date.isPreviousMonth, \'next-month\': date.isNextMonth, \'is-selected\': date.isSelected }" ng-click="tableCtrl.onDateSelected(date.date)">\n' +
    '				{{ date.date.getDate() | pad }}\n' +
    '			</td>\n' +
    '		</tr>\n' +
    '	</tbody>\n' +
    '</table>');
}]);
})();
