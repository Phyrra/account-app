app
	.component('accountHeader', {
		templateUrl: 'components/account-header/account-header.html',
		transclude: true,
		controller: 'AccountHeaderController',
		controllerAs: 'headerCtrl',
		bindings: {
			showSidebar: '=',
			showFilterMenu: '='
		}
	})

	.controller('AccountHeaderController', ['$scope', '$timeout', function($scope, $timeout) {
		var ctrl = this;

		ctrl.hideSidebar = function() {
			ctrl.showSidebar = false;
		};

		ctrl.onToggleSidebar = function() {
			ctrl.showSidebar = !ctrl.showSidebar;
		};

		ctrl.onToggleFilterMenu = function() {
			ctrl.showFilterMenu = !ctrl.showFilterMenu;
		};

		$scope.$on('document-click', function($event, event) {
			var $target = $(event.target);

			if (!$target.isOrChildOf('.app-sidebar') && !$target.isOrChildOf('.account-header > .fa-bars')) {
				$timeout(function() {
					ctrl.hideSidebar();
				}, 0);
			}
		});
	}]);
app
	.component('accountView', {
		templateUrl: 'components/account-view/account-view.html',
		controller: 'AccountViewController',
		controllerAs: 'accountCtrl'
	})

	.controller('AccountViewController', ['$scope', 'AccountService', '$q', function($scope, AccountService, $q) {
		var ctrl = this;

		ctrl.MAX_OPEN_ON_START = 1;

		ctrl.SEARCH_KEYS = ['category.name', 'title', 'description'];

		ctrl.showSidebar = false;
		ctrl.showFilterMenu = false;

		ctrl.selectedAccount = null;

		ctrl.balances = [];

		ctrl.expenses = [];
		ctrl.filteredExpenses = [];
		ctrl.categoryFilteredExpenses = [];
		ctrl.searchFilteredExpenses = [];

		var listToMap = function(list, key) {
			var map = {};

			list.forEach(function(element) {
				map[element[key]] = element;
			});

			return map;
		};

		var getCommonElements = function(key) {
			var listOfLists = arguments;

			var map = listToMap(listOfLists[1], key);

			Array.prototype.slice.call(listOfLists, 2).forEach(function(list) {
				var newMap = {};

				list.forEach(function(element) {
					var keyValue = element[key];

					if (map.hasOwnProperty(keyValue)) {
						newMap[keyValue] = map[keyValue];
					}
				});

				map = newMap;
			});

			return map;
		};

		ctrl.onCategoryFilterChange = function(dstModel) {
			ctrl.categoryFilteredExpenses = dstModel;

			ctrl.filterExpenses();
		};

		ctrl.onSearchFilterChange = function(dstModel) {
			ctrl.searchFilteredExpenses = dstModel;

			ctrl.filterExpenses();
		};

		// TODO: Race condition?!
		ctrl.filterExpenses = function() {
			var key = 'id';

			var commonFilteredExpenses = getCommonElements('id', ctrl.categoryFilteredExpenses, ctrl.searchFilteredExpenses);

			ctrl.filteredExpenses = ctrl.expenses.filter(function(expense) {
				return commonFilteredExpenses.hasOwnProperty(expense[key]);
			});
		};

		ctrl.getExpensesInDateRange = function(expenses, balance) {
			return expenses.filter(function(expense) {
				if (ctrl.balances.length === 1) { // there's always at least 1 "mock" balance
					return true;
				}

				var idx = ctrl.balances.indexOf(balance);

				if (idx === -1) {
					return false;
				}

				if (idx === 0) {
					// idx 0 is a "mock" balance to catch all the newest expenses
					var lastBalance = ctrl.balances[1];

					return expense.date >= lastBalance.date;
				} else if (idx === ctrl.balances.length - 1) {
					return expense.date < balance.date;
				} else {
					var previousBalance = ctrl.balances[idx + 1];

					return expense.date >= previousBalance.date && expense.date < balance.date;
				}
			});
		};

		ctrl.deleteExpense = function(expense) {
			var idx = ctrl.expenses.indexOf(expense);

			if (idx !== -1) {
				AccountService.deleteExpense(expense).then(function(response) {
					if (response.success) {
						ctrl.expenses.splice(idx, 1);

						ctrl.expenses = ctrl.expenses.slice(); // do this to trigger the update across the scopes
					}
				});
			}
		};

		ctrl.deleteBalance = function(balance) {
			var idx = ctrl.balances.indexOf(balance);

			if (idx !== -1) {
				AccountService.deleteBalance(balance).then(function(response) {
					if (response.success) {
						ctrl.balances.splice(idx, 1);

						ctrl.balances = ctrl.balances.slice(); // do this to trigger the update across the scopes
					}
				});
			}
		};

		ctrl.updateExpense = function(expense) {
			ctrl.loadData('expenses', expense.id);
		};

		ctrl.updateBalance = function(balance) {
			ctrl.loadData('balances', balance.id);
		};

		ctrl.loadData = function(field, id) {
			$q.all({
				balances: AccountService.getBalances(ctrl.selectedAccount),
				expenses: AccountService.getExpenses(ctrl.selectedAccount)
			}).then(function(result) {
				ctrl.balances = result.balances;
				ctrl.expenses = result.expenses;

				ctrl.balances.unshift({});

				if (angular.isDefined(field) && angular.isDefined(ctrl[field])) {
					ctrl[field].some(function(obj) {
						if (obj.id === id) {
							obj.isNew = true;

							return true;
						}

						return false;
					});
				}

				// FIXME: bit of a hack to prevent animation on first load
				// the 1000 is a "measured-guess"
				setTimeout(function() {
					$('.view').addClass('animation-foldout-scroll-parent');
				}, 1000);
			});
		};

		ctrl.updateCategories = function(categories) {
		    var map = {};

		    categories.forEach(function(category) {
		        map[category.id] = category;
		    });

		    ctrl.expenses.forEach(function(expense) {
		        if (map[expense.categoryId]) {
		            expense.category = map[expense.categoryId];
		        }
		    });
		};

		$scope.$watch('accountCtrl.selectedAccount', function(value, oldValue) {
			if (value && value !== oldValue) {
				ctrl.loadData();
			}
		});
	}]);
app
	.component('analysisBlock', {
		templateUrl: 'components/analysis-block/analysis-block.html',
		controller: 'AnalysisBlockController',
		controllerAs: 'analysisCtrl',
		bindings: {
			expenses: '<'
		}
	})

	.controller('AnalysisBlockController', ['DataService', '$timeout', '$filter', '$scope', function(DataService, $timeout, $filter, $scope) {
		var ctrl = this;

		ctrl.showContent = false;

		ctrl.filterExpenses = function() {
			ctrl.filteredExpenses = ctrl.expenses
				.filter(function(expense) {
					return expense.date >= ctrl.dateStart && expense.date <= ctrl.dateEnd;
				});
		};

		ctrl.onContentToggle = function() {
			ctrl.showContent = !ctrl.showContent;

			if (ctrl.showContent) {
				if (angular.isUndefined(ctrl.dateStart)) {
					ctrl.dateStart = ctrl.expenses[ctrl.expenses.length - 1].date;
				}

				if (angular.isUndefined(ctrl.dateEnd)) {
					ctrl.dateEnd = ctrl.expenses[0].date;
				}

				ctrl.filterExpenses();
			}
		};
	}]);
app
	.component('appSidebar', {
		templateUrl: 'components/app-sidebar/app-sidebar.html',
		controller: 'AppSidebarController',
		controllerAs: 'sidebarCtrl',
		transclude: true,
		bindings: {
			show: '='
		}
	})

	.controller('AppSidebarController', ['$location', function($location) {
		var ctrl = this;

		ctrl.items = [{
			text: 'Backup',
			action: function() {
				Android.createBackupDump();
			}
		}, {
			text: 'Restore',
			action: function() {
				Android.restoreBackupDump();

				// TODO: this is hacky, don't know how to require ng-view controller?
				angular.element('div[ng-view]').scope().accountCtrl.loadData();
			}
		}];

		ctrl.onItemClick = function(item) {
			if (angular.isString(item.link)) {
				$location.url(item.link.substring(1));
			}

			if (angular.isFunction(item.action)) {
				item.action();
			}

			ctrl.show = false;
		};

		ctrl.isActive = function(item) {
			return '#' + $location.url().replace(/\?.*$/, '') === item.link;
		};
	}]);
app
	.component('balanceBlock', {
		templateUrl: 'components/balance-block/balance-block.html',
		controller: 'BalanceBlockController',
		controllerAs: 'blockCtrl',
		require: {
			accountCtrl: '^^accountView' // AccountViewController
		},
		bindings: {
			model: '<ngModel',
			expenses: '<',
			openOnInit: '<',
			isLast: '<'
		}
	})

	.controller('BalanceBlockController', ['ModalService', function(ModalService) {
		var ctrl = this;

		ctrl.filteredExpenses = [];

		ctrl.onContentToggle = function() {
			ctrl.showContent = !ctrl.showContent;
		};

		ctrl.onEdit = function() {
			if (!angular.isDefined(ctrl.model.id)) {
				return;
			}

			ModalService.open({
				header: 'Edit',
				buttons: [
					{
						isPrimary: true,
						icon: 'fa-floppy-o',
						action: function(content) {
							var inputMaskCtrl = content
								.find('.balance-input-mask').scope()
								.inputMaskCtrl;

							if (inputMaskCtrl.validate()) {
							    inputMaskCtrl.onUpdate().then(function(balance) {
                                    ModalService.close();

                                    ctrl.accountCtrl.updateBalance(balance);
                                });
							}
						}
					}, {
						icon: 'fa-trash-o',
						action: function(content) {
							ctrl.accountCtrl.deleteBalance(ctrl.model);

							ModalService.close();
						}
					}, {
						icon: 'fa-times',
						action: function(content) {
							ModalService.close();
						}
					}
				],
				balance: ctrl.model,
				content: '<balance-input-mask ng-model="balance"></balance-input-mask>'
			});
		};

		ctrl.$onChanges = function(changes) {
			if (changes.expenses) {
				ctrl.filteredExpenses = ctrl.accountCtrl.getExpensesInDateRange(changes.expenses.currentValue, ctrl.model);
			}
		};

		ctrl.$onInit = function() {
			ctrl.showContent = ctrl.openOnInit === true;
		};
	}]);
app
	.directive('bindValue', ['$parse', function($parse) {
		return {
			restrict: 'A',
			link: function($scope, $element, $attrs) {
				var watcher = $scope.$watch(function() { // gets called every digest cycle
					$parse($attrs.bindValue)($scope);
				});
			}
		};
	}]);
app
	.component('expenseAnalysisChart', {
		templateUrl: 'components/expense-analysis-chart/expense-analysis-chart.html',
		controller: 'ExpenseAnalysisChartController',
		controllerAs: 'chartCtrl',
		bindings: {
			expenses: '<'
		}
	})

	.controller('ExpenseAnalysisChartController', ['DataService', '$timeout', '$filter', '$element', 'UUID', function(DataService, $timeout, $filter, $element, UUID) {
		var ctrl = this;

		var CHART_ID = 'expense-analysis-chart-';

		ctrl.buildRainbowColors = function(n) {
			var decToHex = function(value) {
				var h = value.toString(16);

				if (h.length === 1) {
					return '0' + h;
				}

				return h;
			};

			var frequency = Math.PI / n;

			var colors = [];
			for (var i = 0; i < n; ++i) {
				red = Math.floor(Math.sin(frequency * i + 0) * 127) + 128;
				green = Math.floor(Math.sin(frequency * i + 2 * Math.PI / 3) * 127) + 128;
				blue = Math.floor(Math.sin(frequency * i + 4 * Math.PI / 3) * 127) + 128;

				colors.push('#' + decToHex(red) + decToHex(green) + decToHex(blue));
			}

			return colors;
		};

		ctrl.getPieChartData = function() {
			var columns = ctrl.categories.map(function(category) {
				return [
					category.name,
					ctrl.expenses
						.filter(function(expense) {
							return expense.categoryId === category.id;
						})
						.map(function(expense) {
							return expense.amount;
						})
						.reduce(function(sum, value) {
							return sum + value;
						}, 0)
				];
			})
			.filter(function(value) {
				return value[1] > 0;
			})
			.sort(function(a, b) {
				return a[1] < b[1] ? 1 : -1;
			});

			return {
				columns: columns
			};
		};

		ctrl.getPercentages = function(columns) {
			var sum = columns.reduce(function(iter, column) {
				return iter + column[1];
			}, 0);

			return columns.map(function(column) {
				return column[1] / sum * 100;
			});
		};

		ctrl.buildChart = function() {
			$timeout(function() { // timing hack to let ng-if draw
				$element
					.find('#' + CHART_ID + ctrl.id)
					.empty()
					.append('<div id="' + CHART_ID + ctrl.id + '-chart" style="height: ' + ctrl.getChartHeight() + 'px;"></div>');

				var data = ctrl.getPieChartData();
				var percentages = ctrl.getPercentages(data.columns);

				var chart = c3.generate({
					bindto: '#' + CHART_ID + ctrl.id + '-chart',
					data: {
						type: 'pie',
						columns: data.columns
					},
					color: {
						pattern: ctrl.buildRainbowColors(data.columns.length)
					},
					pie: {
						label: {
							show: false
						}
					},
					tooltip: {
						format: {
							title: function() {
								return 'Expenses';
							},
							value: function(value, ratio, id) {
								var filter = $filter('number');

								return filter(ratio * 100, 2) + '% (' + filter(value, 2) + 'CHF)';
							}
						}
					},
					legend: {
						show: false
					}
				});

				d3.select('#' + CHART_ID + ctrl.id)
					.insert('div')
					.attr('class', 'chart-legend')
					.insert('div')
					.attr('class', 'chart-legend-content')
					.selectAll()
					.data(data.columns.map(function(column) {
						return column[0];
					}))
					.enter()
						.append('div')
						.attr('class', 'chart-legend-label')
						.html(function(id, idx) {
							if (data.columns[idx][1] === 0) {
								return '';
							}

							return '<i class="chart-legend-label-icon" style="background-color: ' + chart.color(id) + '"></i>' +
								id +
								', ' +
								$filter('number')(percentages[idx]) + '%' +
								' ' +
								'(' + $filter('number')(data.columns[idx][1]) + 'CHF)';
						})
						.on('mouseover', function(id) {
							chart.focus(id);
						})
						.on('mouseout', function() {
							chart.revert();
						})
						.on('click', function(id) {
							chart.focus(id);
						});
			}, 0, false);
		};

		ctrl.getChartHeight = function() {
			return $element.parent().width() / 2.0;
		};

		ctrl.$onChanges = function(changes) {
			if (changes.expenses) {
				if (ctrl.categories && ctrl.categories.length > 0) {
					ctrl.buildChart();
				}
			}
		};

		ctrl.$onInit = function() {
			ctrl.id = UUID();

			DataService.getCategories().then(function(categories) {
				ctrl.categories = categories;

				ctrl.buildChart();
			});
		};
	}]);
app
	.component('expenseProgressChart', {
		templateUrl: 'components/expense-progress-chart/expense-progress-chart.html',
		controller: 'ExpenseProgressChartController',
		controllerAs: 'chartCtrl',
		bindings: {
			balances: '<',
			expenses: '<',
			model: '<ngModel'
		}
	})

	.controller('ExpenseProgressChartController', ['UUID', '$timeout', '$filter', '$document', function(UUID, $timeout, $filter, $document) {
		var ctrl = this;

		ctrl.id = null;

		ctrl.SLICE_WIDTH = 66;
		ctrl.SWIPE_FADEOUT = 500;

		ctrl.getColumnData = function() {
			var column = [];
			var regionIdx = -1;

			var tmpExpenses = ctrl.expenses.slice().reverse();
			var curIdx = 0;

			var tmpBalances = ctrl.balances.slice(1).reverse(); // remove the "mock"

			var current;
			var lastDate;

			var filter = $filter('date');

			tmpBalances
				.forEach(function(balance, idx) {
					column.push({
						amount: balance.amount,
						date: balance.date
					});

					current = balance.amount;
					lastDate = balance.date;

					var next = idx < tmpBalances.length - 1 ? tmpBalances[idx + 1] : null;

					for (; curIdx < tmpExpenses.length; ++curIdx) {
						var expense = tmpExpenses[curIdx];

						if (next !== null && expense.date >= next.date) {
							break;
						}

						if (expense.date >= balance.date) {
							current -= expense.amount;

							if (lastDate.getTime() === expense.date.getTime()) {
								column[column.length - 1].amount = current;
							} else {
								column.push({
									amount: current,
									date: expense.date
								});

								lastDate = expense.date;
							}

							if (ctrl.model.id === expense.id) {
								regionIdx = column.length - 1;
							}
						}
					}
				});

			return {
				column: column,
				regionIdx: regionIdx
			};
		};

		ctrl.initSliding = function($element) {
			var swiping = false;
			var initialX;
			var startX;
			var curX;
			var curTimeStamp;
			var swipeXSpeed;

			var parent = $element.parent();

			var cropValue = function(value) {
				return Math.max(
					parent.outerWidth() - $element.outerWidth(),
					Math.min(
						0,
						value
					)
				);
			};

			// fix initial scroll
			$element.css('left', cropValue($element.offset().left - parent.offset().left));

			$element.on('mousedown touchstart', function(event) {
				event.stopPropagation();

				swiping = true;

				startX = event.clientX || event.originalEvent.touches[0].clientX;
				curX = startX;
				curTimeStamp = event.timeStamp;

				initialX = $element.offset().left - parent.offset().left;
			});

			$element.on('mousemove touchmove', function(event) {
				if (swiping) {
					var newX = event.clientX || event.originalEvent.touches[0].clientX;
					var timeStamp = event.timeStamp;

					swipeXSpeed = (newX - curX) / (timeStamp - curTimeStamp);
					curX = newX;

					curTimeStamp = timeStamp;

					$element.css('left', cropValue(initialX + curX - startX));
				}
			});

			$document.on('mouseup touchend', function() {
				if (swiping) {
					$element.animate({
						left: cropValue($element.offset().left - parent.offset().left + swipeXSpeed * ctrl.SWIPE_FADEOUT)
					}, {
						duration: ctrl.SWIPE_FADEOUT,
						easing: 'linear'
					});
				}

				swiping = false;
			});
		};

		ctrl.prepareChartDataWithSpacing = function(columnData) {
			var day0;
			if (columnData.column.length > 0) {
				day0 = columnData.column[0].date;
			}

			var dateDiff = function(date1, date2) {
				var timeDiff = date2.getTime() - date1.getTime();
				return Math.ceil(timeDiff / (1000 * 3600 * 24));
			};

			var x1 = columnData.column.map(function(value) {
				return dateDiff(day0, value.date);
			});

			var data1 = columnData.column.map(function(value) {
				return value.amount;
			});

			var balances = ctrl.balances.slice(1).reverse();

			var x2 = balances.map(function(balance) {
				return dateDiff(day0, balance.date);
			});

			var data2 = balances.map(function(balance) {
				return balance.amount;
			});

			var data1Labels = [];
			var xLabels = [];
			columnData.column.forEach(function(value) {
				var label = $filter('date')(value.date);

				data1Labels.push(label);

				var idx = dateDiff(day0, value.date);
				xLabels[idx] = label;
			});

			var data2Labels = balances.map(function(balance) {
				return $filter('date')(balance.date);
			});

			var regionIdx = dateDiff(day0, columnData.column[columnData.regionIdx].date);

			return {
				x1: x1,
				data1: data1,
				x2: x2,
				data2: data2,
				labels: {
					xLabels: xLabels,
					data1: data1Labels,
					data2: data2Labels
				},
				regionIdx: regionIdx,
				chartWidth: xLabels.length * ctrl.SLICE_WIDTH
			};
		};

		ctrl.$onInit = function() {
			ctrl.id = 'chart-' + UUID();

			var columnData = ctrl.getColumnData();
			ctrl.chartData = ctrl.prepareChartDataWithSpacing(columnData);

			$timeout(function() { // little hack to let Angular draw
				c3.generate({
					bindto: '#' + ctrl.id,
					data: {
						xs: {
							'data1': 'x1',
							'data2': 'x2'
						},
						columns: [
							['x1'].concat(ctrl.chartData.x1),
							['data1'].concat(ctrl.chartData.data1),

							['x2'].concat(ctrl.chartData.x2),
							['data2'].concat(ctrl.chartData.data2)
						],
						types: {
							data1: 'line',
							data2: 'line'
						}
					},
					axis: {
						x: {
							padding: {
								left: 0.5,
								right: 0.5
							},
							tick: {
								culling: {
									max: 1
								},
								format: function(x) {
									return ctrl.chartData.labels.xLabels[x];
								}
							}
						},
						y: {
							show: false
						}
					},
					legend: {
						show: false
					},
					tooltip: {
						format: {
							title: function() {
								return 'Balance';
							},
							name: function(name, ratio, id, idx) {
								return ctrl.chartData.labels[id][idx];
							},
							value: function(value, ratio, id) {
								return $filter('number')(value);
							}
						}
					},
					regions: [{
						axis: 'x',
						start: ctrl.chartData.regionIdx - 0.5,
						end: ctrl.chartData.regionIdx + 0.5,
						class: 'current-expense'
					}]
				});

				var $element = $('#' + ctrl.id);

				if (ctrl.chartData.regionIdx !== -1) {
					$element.css('left', -ctrl.chartData.regionIdx * ctrl.SLICE_WIDTH + $element.parent().outerWidth() / 4.0);
				}

				ctrl.initSliding($element);
			}, 0, false);
		};
	}]);
app
	.constant('MODAL_ANIMATION_DURATION', 500)

	.service('ModalService', ['$compile', '$rootScope', '$document', 'MODAL_ANIMATION_DURATION', '$window', function($compile, $rootScope, $document, DURATION, $window) {
		var service = {};

		service.open = function(options) {
			var $scope = $rootScope.$new();
			Object.assign($scope, options);
			delete $scope.content;

			var base = $('<fullscreen-modal header="{{header}}" buttons="buttons"></fullscreen-modal>')
				.append(options.content);

			var $element = $compile(base)($scope);

			$document
				.find('body')
				.append($element);

			Android.onOpenModal();
		};

		service.close = function() {
			$('.modal-wrapper')
				.css('opacity', 1)
				.animate({
					opacity: 0
				}, {
					duration: DURATION,
					done: function() {
						$('fullscreen-modal').remove();
					}
				});

			Android.onCloseModal();
		};

		$window.closeModal = service.close;

		return service;
	}])

	.component('fullscreenModal', {
		templateUrl: 'components/fullscreen-modal/fullscreen-modal.html',
		transclude: true,
		controller: 'ModalController',
		controllerAs: 'modalCtrl',
		bindings: {
			header: '@',
			buttons: '<?'
		}
	})

	.controller('ModalController', ['ModalService', 'MODAL_ANIMATION_DURATION', '$element', function(ModalService, DURATION, $element) {
		var ctrl = this;

		ctrl.onButtonClick = function(button) {
			if (angular.isFunction(button.action)) {
				// TODO: don't know any better way to pass the "content" of the modal
				button.action($element.find('.modal-content'));
			}
		};

		ctrl.$onInit = function() {
			$('.modal-body')
				.css('opacity', 0)
				.animate({
					opacity: 1
				}, {
					duration: DURATION
				});
		};
	}]);
app
	.component('expenseItem', {
		templateUrl: 'components/expense-item/expense-item.html',
		controller: 'expenseItemController',
		controllerAs: 'expenseItemCtrl',
		require: {
			accountCtrl: '^^accountView' // AccountViewController
		},
		bindings: {
			model: '<ngModel',
			isLastBlock: '<'
		}
	})
	
	.controller('expenseItemController', ['ModalService', function(ModalService) {
		var ctrl = this;

		ctrl.showDetail = false;

		ctrl.onToggleDetail = function() {
			ctrl.showDetail = !ctrl.showDetail;
		};

		ctrl.onEdit = function() {
			ModalService.open({
				header: 'Edit',
				buttons: [
					{
						isPrimary: true,
						icon: 'fa-floppy-o',
						action: function(content) {
							var inputMaskCtrl = content
								.find('.expense-input-mask').scope()
								.inputMaskCtrl;

							if (inputMaskCtrl.validate()) {
							    inputMaskCtrl.onUpdate().then(function(expense) {
                                    ctrl.accountCtrl.updateExpense(expense);

                                    ModalService.close();
                                });
							}
						}
					}, {
						icon: 'fa-trash-o',
						action: function(content) {
							ctrl.accountCtrl.deleteExpense(ctrl.model);

							ModalService.close();
						}
					}, {
						icon: 'fa-times',
						action: function(content) {
							ModalService.close();
						}
					}
				],
				expense: ctrl.model,
				content: '<expense-input-mask ng-model="expense"></expense-input-mask>'
			});
		};

		var entityMap = {
			'<': '&lt;',
			'>': '&gt;'
		};

		var escapeHtml = function(string) {
			return string.replace(/[<>]/g, function(s) {
				return entityMap[s];
			});
		};

		ctrl.$onChanges = function(changes) {
			if (changes.model) {
			    if (changes.model.currentValue.description) {
				    ctrl.displayDescription = escapeHtml(changes.model.currentValue.description).replace(/(?:\r\n|\r|\n)/g, '<br />');
				}
			}
		};
	}]);
app
	.constant('FOLDOUT_ANIMATION_DURATION', 500)

	.animation('.foldout-animation', ['FOLDOUT_ANIMATION_DURATION', function(DURATION) {
		var getAnimationTarget = function(element) {
			var attr = element.attr('target-height');

			if (angular.isDefined(attr)) {
				return {
					property: 'max-height',
					value: parseInt(attr, 10)
				};
			}

			return {
				property: 'height',
				value: element.height()
			};
		};

		var getDuration = function(element) {
			var attr = element.attr('animation-time');

			if (angular.isDefined(attr)) {
				return parseInt(attr, 10);
			}

			return DURATION;
		};

		var enter = function(element, done) {
			var target = getAnimationTarget(element);

			element.css(target.property, 0);
			element.css('overflow-y', 'hidden');

			var animationTarget = {};
			animationTarget[target.property] = target.value;

			var duration = getDuration(element);

			var scrollParent = element.closest('.animation-foldout-scroll-parent');
			if (scrollParent.length > 0) {
				var scrollTop = scrollParent.scrollTop();

				var parentOffset = scrollParent.offset().top;
				var parentHeight = scrollParent.outerHeight();
				var parentPaddingBottom = parseInt(scrollParent.css('padding-bottom').replace(/px/, '') || '0', 10);

				var elementOffset = element.offset().top;
				var targetHeight = target.value;

				if (elementOffset < parentOffset || elementOffset + targetHeight > parentOffset + parentHeight - parentPaddingBottom) {
					scrollParent.animate({
						scrollTop: Math.max(0, elementOffset + targetHeight - parentOffset - parentHeight + scrollTop + parentPaddingBottom)
					}, {
						duration: duration
					});
				}
			}

			element.animate(animationTarget,
			{
				duration: duration,
				done: function() {
					element.css(target.property, '');
					element.css('overflow-y', '');

					done();
				}
			});
		};

		var leave = function(element, done) {
			var initialHeight = element.height();
			element.css('height', initialHeight);

			element.animate({
				height: 0
			}, {
				duration: getDuration(element),
				done: function() {
					element.css('height', '');
					done();
				}
			});
		};

		return {
			/*
			ng-if
			*/
			enter: enter,
			leave: leave,

			/*
			ng-show
			*/
			beforeRemoveClass: function(element, cls, done) {
				enter(element, done);
			},
			beforeAddClass: function(element, cls, done) {
				leave(element, done);
			}
		};
	}]);
app
	.directive('onLongClick', ['$parse', '$interval', '$timeout', function($parse, $interval, $timeout) {
		return {
			restrict: 'A',
			link: function($scope, $element, $attrs) {
				var DEFAULT_TIME_DELAY = 1000;
				var TOLERANCE = 16;

				var timeDelay;
				if ($attrs.hasOwnProperty('timeDelay')) {
					timeDelay = parseInt($attrs.timeDelay, 10);
				} else {
					timeDelay = DEFAULT_TIME_DELAY;
				}

				var callback = $parse($attrs.onLongClick);

				var eventStart = null;
				var eventInterval = null;

				var startX;
				var startY;

				var reset = function() {
					$interval.cancel(eventInterval);
					eventInterval = null;
				};

				$element.on('mousedown touchstart', function(event) {
					eventStart = new Date();
					startX = event.clientX || event.originalEvent.touches[0].clientX;
					startY = event.clientY || event.originalEvent.touches[0].clientY;

					if (!eventInterval) {
						eventInterval = $interval(function() {
							if (new Date().getTime() - eventStart.getTime() > timeDelay) {
								$timeout(function() {
									callback($scope);
								}, 0);

								reset();
							}
						}, 10);
					}
				});

				$element.on('mousemove touchmove', function(event) {
					var newX = event.clientX || event.originalEvent.touches[0].clientX;
					var newY = event.clientY || event.originalEvent.touches[0].clientY;

					if (Math.abs(newX - startX) > TOLERANCE || Math.abs(newY - startY) > TOLERANCE) {
						if (eventInterval) {
							reset();
						}
					}
				});

				$element.on('mouseup touchend mouseout mouseleave', function() {
					if (eventInterval) {
						reset();
					}
				});
			}
		};
	}]);
app
	.constant('SWIPE_DIRECTION', {
		LEFT: 'left',
		RIGHT: 'right'
	})

	.directive('onSwipe', ['$parse', '$document', '$timeout', 'SWIPE_DIRECTION', function($parse, $document, $timeout, SWIPE_DIRECTION) {
		return {
			restrict: 'A',
			link: function($scope, $element, $attrs) {
				var DEFAULT_EXECUTE_FRACTION = 0.5;
				var MIN_ANIMATION_TIME = 500;
				var Y_TOLERANCE_MIN = 32;
				var Y_TOLERANCE_FACTOR = 0.75;

				var swipeValidator = {
					'left': function(newX, oldX) {
						return newX <= oldX;
					},

					'right': function(newX, oldX) {
						return newX >= oldX;
					}
				};

				var executeFraction;
				if ($attrs.hasOwnProperty('executeFraction')) {
					executeFraction = parseFloat($attrs.executeFraction);
				} else {
					executeFraction = DEFAULT_EXECUTE_FRACTION;
				}

				var width = null;

				var swipeDirection = null;
				if ($attrs.hasOwnProperty('swipeDirection')) {
					swipeDirection = $attrs.swipeDirection;
				}

				var callback = null;
				if (angular.isDefined($attrs.onSwipe)) {
					callback = $parse($attrs.onSwipe);
				} else {
					callback = angular.noop;
				}

				var running = false;

				var startX;
				var startY;
				var curX;

				var lastTimeStamp;
				var swipeXSpeed;

				var reset = function() {
					startX = null;
					startY = null;
					curX = null;
					lastTimeStamp = null;
					swipeXSpeed = null;

					running = false;
				};

				$element.on('mousedown touchstart', function(event) {
					running = true;
					startX = event.clientX || event.originalEvent.touches[0].clientX;
					startY = event.clientY || event.originalEvent.touches[0].clientY;
					curX = startX;

					width = $element.parent().width();
				});

				$element.on('mousemove touchmove', function(event) {
					if (running) {
						var newX = event.clientX || event.originalEvent.touches[0].clientX;
						var newY = event.clientY || event.originalEvent.touches[0].clientY;

						var timeStamp = event.timeStamp;

						var doReset = false;

						if (angular.isFunction(swipeValidator[swipeDirection])) {
							if (!swipeValidator[swipeDirection](newX, curX)) {
								doReset = true;
							}
						}

						if (Math.abs(startY - newY) > Math.max(Y_TOLERANCE_MIN, Math.abs(startX - newX) * Y_TOLERANCE_FACTOR)) {
							doReset = true;
						}

						if (doReset) {
							$element.css('left', '');

							reset();
						}
					}

					if (running) {
						swipeXSpeed = (newX - curX) / (timeStamp - lastTimeStamp);
						curX = newX;

						lastTimeStamp = timeStamp;

						$element.css('left', curX - startX);
					}
				});

				$document.on('mouseup touchend', function() {
					if (running) {
						if (Math.abs(curX - startX) > width * executeFraction || Math.abs(swipeXSpeed) > 1) {
							var left = $element.position().left;
							var time = Math.abs((width - left) / swipeXSpeed);

							$element.animate({
								left: Math.sign(swipeXSpeed) * width
							}, {
								duration: Math.min(time || MIN_ANIMATION_TIME, MIN_ANIMATION_TIME),
								easing: 'linear',
								done: function() {
									$timeout(function() {
										callback(
											$scope,
											{
												direction: left > 0 ? SWIPE_DIRECTION.RIGHT : SWIPE_DIRECTION.LEFT
											}
										);
									}, 0);

									$element.css('left', '');
								}
							});
						} else {
							$element.css('left', '');
						}
					}

					reset();
				});
			}
		};
	}]);
app
	.component('addDataButton', {
		templateUrl: 'components/add-data/add-data-button/add-data-button.html',
		controller: 'AddDataButtonController',
		controllerAs: 'buttonCtrl',
		require: {
			accountCtrl: '^^accountView' // AccountViewController
		}
	})

	.controller('AddDataButtonController', ['ModalService', function(ModalService) {
		var ctrl = this;

		ctrl.onButtonClick = function() {
			ModalService.open({
				header: 'Create',
				buttons: [
					{
						isPrimary: true,
						icon: 'fa-floppy-o',
						action: function(content) {
							content
								.find('.add-data-dialog').scope()
								.addDataCtrl.onClickSave()
								.then(function(response) {
									if (response.success) {
										ModalService.close();

										ctrl.accountCtrl.loadData(response.field, response.id);
									}
								});
						}
					}, {
						icon: 'fa-times',
						action: function(content) {
							ModalService.close();
						}
					}
				],
				accountId: ctrl.accountCtrl.selectedAccount.id,
				content: '<add-data-dialog account-id="accountId"></add-data-dialog>'
			});
		};
	}]);
app
	.component('balanceInputMask', {
		templateUrl: 'components/add-data/balance-input-mask/balance-input-mask.html',
		controller: 'BalanceInputMaskController',
		controllerAs: 'inputMaskCtrl',
		bindings: {
			model: '<?ngModel'
		}
	})

	.controller('BalanceInputMaskController', ['AccountService', '$element', function(AccountService, $element) {
		var ctrl = this;

		ctrl.onCreate = function(accountId) {
			return AccountService.addBalance({
				accountId: accountId,
				amount: ctrl.amount,
				date: ctrl.date
			});
		};

		ctrl.onUpdate = function() {
			return AccountService.updateBalance({
				id: ctrl.model.id,
				accountId: ctrl.model.accountId,
				amount: ctrl.amount,
				date: ctrl.date
			});
		};

		ctrl.validate = function() {
		    var valid = true;

			if (!ctrl.amount) {
				$element.find('.amount input').addClass('required');

				valid = false;
			}

			return valid;
		};

		ctrl.$onInit = function() {
			if (angular.isDefined(ctrl.model)) {
				ctrl.amount = ctrl.model.amount;
				ctrl.date = ctrl.model.date;
			}
		};
	}]);
app
	.component('contentTabs', {
		templateUrl: 'components/add-data/content-tabs/content-tabs.html',
		controller: 'ContentTabsController',
		controllerAs: 'tabsCtrl',
		bindings: {
			model: '=ngModel',
			tabs: '<'
		}
	})

	.controller('ContentTabsController', [function() {
		var ctrl = this;

		ctrl.onTabSelect = function(tab) {
			ctrl.model = tab.value;
			ctrl.display = tab.text;
		};

		ctrl.setDisplay = function() {
			ctrl.tabs.some(function(tab) {
				if (ctrl.model === tab.value) {
					ctrl.display = tab.text;
				}
			});
		};

		ctrl.$onInit = function() {
			if (!ctrl.model && ctrl.tabs.length > 0) {
				ctrl.model = ctrl.tabs[0].value;
			}

			ctrl.setDisplay();
		};
	}]);
app
	.component('expenseInputMask', {
		templateUrl: 'components/add-data/expense-input-mask/expense-input-mask.html',
		controller: 'ExpenseInputMaskController',
		controllerAs: 'inputMaskCtrl',
		bindings: {
			model: '<?ngModel'
		}
	})

	.controller('ExpenseInputMaskController', ['DataService', 'AccountService', '$element', function(DataService, AccountService, $element) {
		var ctrl = this;

		ctrl.categories = [];

		ctrl.validate = function() {
		    var valid = true;

			if (!ctrl.category) {
				$element.find('.category .dropdown-input').addClass('required');

				valid = false;
			}

			if (!ctrl.amount) {
				$element.find('.amount input').addClass('required');

				valid = false;
			}

			if (!ctrl.title) {
				$element.find('.title input').addClass('required');

				valid = false;
			}

			return valid;
		};

		ctrl.onCreate = function(accountId) {
			return AccountService.addExpense({
				accountId: accountId,
				categoryId: ctrl.category.id,
				title: ctrl.title,
				amount: ctrl.amount,
				description: ctrl.description,
				date: ctrl.date
			});
		};

		ctrl.onUpdate = function() {
			return AccountService.updateExpense({
				id: ctrl.model.id,
				accountId: ctrl.model.accountId,
				categoryId : ctrl.category.id,
				title: ctrl.title,
				amount: ctrl.amount,
				description: ctrl.description,
				date: ctrl.date
			});
		};

		ctrl.renderCategory = function(category) {
            return  '<span class="expense-input-category-option">' +
                        (category.icon ? '<i class="fa fa-' + category.icon + '"></i>' : '')+
                        category.name +
                    '</span>';
		};

		ctrl.$onInit = function() {
			DataService.getCategories().then(function(categories) {
				ctrl.categories = categories;

				if (angular.isDefined(ctrl.model)) {
				    ctrl.categories.some(function(category) {
				        if (category.id === ctrl.model.categoryId) {
				            ctrl.category = category;

				            return true;
				        }

				        return false;
				    });
				}
			});

			if (angular.isDefined(ctrl.model)) {
				ctrl.title = ctrl.model.title;
				ctrl.amount = ctrl.model.amount;
				ctrl.description = ctrl.model.description;
				ctrl.date = ctrl.model.date;
			}
		};
	}]);
app
	.component('addDataDialog', {
		templateUrl: 'components/add-data/add-data-dialog/add-data-dialog.html',
		controller: 'AddDataDialogController',
		controllerAs: 'addDataCtrl',
		bindings: {
			accountId: '<'
		}
	})

	.controller('AddDataDialogController', ['$element', '$q', function($element, $q) {
		var ctrl = this;

		ctrl.tabs = [{
			value: 1,
			text: 'Expense'
		}, {
			value: 2,
			text: 'Balance'
		}];

		ctrl.selectedTab = null;

		ctrl.onSaveExpense = function() {
			var inputMaskCtrl = $element.find('.expense-input-mask').scope().inputMaskCtrl;

			if (inputMaskCtrl.validate()) {
				return inputMaskCtrl.onCreate(ctrl.accountId).then(function(expense) {
					return {
						success: true,
						field: 'expenses',
						id: expense.id
					};
				});
			} else {
				return $q.resolve({
					success: false
				});
			}
		};

		ctrl.onSaveBalance = function() {
			var inputMaskCtrl = $element.find('.balance-input-mask').scope().inputMaskCtrl;

			if (inputMaskCtrl.validate()) {
				return inputMaskCtrl.onCreate(ctrl.accountId).then(function(balance) {
					return {
						success: true,
						field: 'balances',
						id: balance.id
					};
				});
			} else {
				return $q.resolve({
					success: false
				});
			}
		};

		ctrl.onClickSave = function() {
			switch (ctrl.selectedTab) {
				case 1:
					return ctrl.onSaveExpense();
				case 2:
					return ctrl.onSaveBalance();
			}
		};
	}]);
app
	.component('dateBlockOption', {
		templateUrl: 'components/analysis-block/date-block-option/date-block-option.html',
		controller: 'DateBlockOptionController',
		controllerAs: 'optionCtrl',
		bindings: {
			dateStart: '=',
			dateEnd: '=',
			onChangeStart: '&',
			onChangeEnd: '&'
		}
	})

	.controller('DateBlockOptionController', ['$scope', function($scope) {
		var ctrl = this;

		$scope.$watch('optionCtrl.dateStart', function(value, oldValue) {
			if (value && value !== oldValue) {
				ctrl.onChangeStart();
			}
		});

		$scope.$watch('optionCtrl.dateEnd', function(value, oldValue) {
			if (value && value !== oldValue) {
				ctrl.onChangeEnd();
			}
		});
	}]);
app
	.component('balanceBlockSummary', {
		templateUrl: 'components/balance-block/balance-block-summary/balance-block-summary.html',
		controller: 'BalanceBlockSummaryController',
		controllerAs: 'summaryCtrl',
		bindings: {
			expenses: '<'
		}
	})

	.controller('BalanceBlockSummaryController', [function() {
		var ctrl = this;

		ctrl.onToggleContent = function() {
			ctrl.showContent = !ctrl.showContent;
		};

		ctrl.$onChanges = function(changes) {
			if (changes.expenses) {
				ctrl.expenseSum = changes.expenses.currentValue.reduce(function(iter, expense) {
					return iter + expense.amount;
				}, 0);
			}
		};
	}]);
app
	.component('accountDropdown', {
		templateUrl: 'components/expense-filter/account-dropdown/account-dropdown.html',
		controller: 'AccountDropdownController',
		controllerAs: 'accountDropdownCtrl',
		bindings: {
			model: '=ngModel'
		}
	})
	
	.controller('AccountDropdownController', ['AccountService', '$location', '$scope', function(AccountService, $location, $scope) {
		var ctrl = this;
		
		ctrl.model = null;
		ctrl.showFoldout = false;
		
		ctrl.closeFoldout = function() {
			ctrl.showFoldout = false;
		};
		
		ctrl.onFoldoutToggle = function() {
			ctrl.showFoldout = !ctrl.showFoldout;
		};
		
		ctrl.onAccountSelected = function(account) {
			// will trigger $routeUpdate which sets model
			$location.search('account', account.id);

			ctrl.closeFoldout();
		};

		ctrl.setAccountById = function(id) {
			ctrl.accounts.some(function(account) {
				if (account.id === id) {
					ctrl.model = account;
					return true;
				}
			});
		};

		$scope.$on('$routeUpdate', function() {
			var id = parseInt($location.search().account, 10);

			ctrl.setAccountById(id);
		});
		
		ctrl.$onInit = function() {
			AccountService.getAccounts().then(function(accounts) {
				ctrl.accounts = accounts;

				if ($location.search().account) {
					var id = parseInt($location.search().account, 10);

					ctrl.setAccountById(id);
				}

				if (!ctrl.model) {
					ctrl.model = ctrl.accounts[0];
				}
			});
		};
	}]);
app
	.component('addCategoryField', {
		templateUrl: 'components/expense-filter/add-category-field/add-category-field.html',
		controller: 'AddCategoryFieldController',
		controllerAs: 'addCategoryCtrl',
		require: {
			categoryFilterCtrl: '^^categoryFilter' // CategoryFilterController
		}
	})

	.controller('AddCategoryFieldController', ['DataService', function(DataService) {
		var ctrl = this;

		ctrl.addCategory = function(name) {
			DataService.addCategory({
				name: name
			}).then(function(category) {
				ctrl.categoryFilterCtrl.addCategory(category);
			});
		};
	}]);
app
	.component('categoryFilter', {
		templateUrl: 'components/expense-filter/category-filter/category-filter.html',
		controller: 'CategoryFilterController',
		controllerAs: 'categoryFilterCtrl',
		require: {
            accountCtrl: '^^accountView' // AccountViewController
        },
		bindings: {
			model: '<ngModel',
			onChange: '&'
		}
	})

	.controller('CategoryFilterController', ['DataService', function(DataService) {
		var ctrl = this;

		ctrl.categories = [];

		ctrl.loadCategories = function() {
			DataService.getCategories().then(function(categories) {
				ctrl.categories = categories;

				ctrl.selectAllCategories();
				ctrl.performFilter();
			});
		};

		ctrl.addCategory = function(category) {
			ctrl.categories.push(category);
		};

		ctrl.updateCategory = function(category) {
			for (var i = 0; i < ctrl.categories.length; ++i) {
				var cat = ctrl.categories[i];

				if (cat.id === category.id) {
					cat.name = category.name;
					cat.icon = category.icon;

					break;
				}
			}

			ctrl.accountCtrl.updateCategories(ctrl.categories);
		};

		ctrl.deleteCategory = function(category) {
			var idx = ctrl.categories.indexOf(category);

			if (idx !== -1) {
				DataService.deleteCategory(category).then(function(response) {
					if (response.success) {
						ctrl.categories.splice(idx, 1);

						ctrl.performFilter();
					}
				});
			}
		};

		ctrl.selectAllCategories = function() {
			ctrl.categories.forEach(function(category) {
				category.checked = true;
			});
		};

		ctrl.isCategorySelected = function(categoryId) {
			return ctrl.categories
				.some(function(category) {
					return category.checked === true && category.id === categoryId;
				});
		};

		ctrl.performFilter = function() {
			var filteredModel = ctrl.model.filter(function(model) {
				return ctrl.isCategorySelected(model.categoryId);
			});

			ctrl.onChange({ dstModel: filteredModel });
		};

		ctrl.$onChanges = function(changes) {
			if (changes.model) {
				ctrl.performFilter();
			}
		};

		ctrl.$onInit = function() {
			ctrl.loadCategories();
		};
	}]);
app
	.component('categoryFilterItem', {
		templateUrl: 'components/expense-filter/category-filter-item/category-filter-item.html',
		controller: 'CategoryFilterItemController',
		controllerAs: 'itemCtrl',
		require: {
			categoryFilterCtrl: '^^categoryFilter' // CategoryFilterController
		},
		bindings: {
			model: '<ngModel'
		}
	})

	.controller('CategoryFilterItemController', ['ModalService', function(ModalService) {
		var ctrl = this;

		ctrl.onEdit = function() {
			ModalService.open({
				header: 'Edit',
				buttons: [
					{
						isPrimary: true,
						icon: 'fa-floppy-o',
						action: function(content) {
							var inputMaskCtrl = content
								.find('.category-input-mask').scope()
								.inputMaskCtrl;

							inputMaskCtrl.validate();

							if (inputMaskCtrl.name) {
								inputMaskCtrl.onUpdate().then(function(category) {
									ctrl.categoryFilterCtrl.updateCategory(category);

									ModalService.close();
								});
							}
						}
					}, {
						icon: 'fa-trash-o',
						action: function(content) {
							ctrl.categoryFilterCtrl.deleteCategory(ctrl.model);

							ModalService.close();
						}
					}, {
						icon: 'fa-times',
						action: function(content) {
							ModalService.close();
						}
					}
				],
				expense: ctrl.model,
				content: '<category-input-mask ng-model="expense"></category-input-mask>'
			});
		};

		ctrl.toggleCategory = function() {
			ctrl.model.checked = !ctrl.model.checked;

			ctrl.categoryFilterCtrl.performFilter();
		};
	}]);
app
	.component('categoryInputMask', {
		templateUrl: 'components/expense-filter/category-input-mask/category-input-mask.html',
		controller: 'CategoryInputMaskController',
		controllerAs: 'inputMaskCtrl',
		bindings: {
			model: '<?ngModel'
		}
	})

	.controller('CategoryInputMaskController', ['DataService', '$element', function(DataService, $element) {
		var ctrl = this;

		ctrl.onSelectIcon = function(icon) {
			ctrl.icon = icon;
		};

		ctrl.validate = function() {
			if (!ctrl.name) {
				$element.find('.name input').addClass('required');
			}
		};

		ctrl.onUpdate = function() {
			return DataService.updateCategory({
				id: ctrl.model.id,
				name: ctrl.name,
				icon: ctrl.icon
			});
		};

		ctrl.$onInit = function() {
			if (angular.isDefined(ctrl.model)) {
				ctrl.name = ctrl.model.name;
				ctrl.icon = ctrl.model.icon;
			}
		};
	}]);
app
	.component('iconSearch', {
		templateUrl: 'components/expense-filter/icon-search/icon-search.html',
		controller: 'IconSearchController',
		controllerAs: 'iconSearchCtrl',
		bindings: {
			model: '<?ngModel',
			onSelect: '&?'
		}
	})

	.controller('IconSearchController', ['FontAwesomeIconService', function(FontAwesomeIconService) {
		var ctrl = this;

		ctrl.iconResults = [];

		ctrl.onChangeSearch = function(search) {
			if (search && search.length > 2) {
				var searchTerm = search.toLowerCase();

				ctrl.iconResults = ctrl.icons.filter(function(icon) {
					return icon.toLowerCase().indexOf(searchTerm) !== -1;
				});
			} else {
				ctrl.iconResults = [];
			}
		};

		ctrl.$onInit = function() {
			FontAwesomeIconService.getIcons().then(function(icons) {
				ctrl.icons = icons;
			});
		};
	}]);
app
	.component('searchFilter', {
		templateUrl: 'components/expense-filter/search-filter/search-filter.html',
		controller: 'SearchFilterController',
		controllerAs: 'searchFilterCtrl',
		bindings: {
			model: '<ngModel',
			keys: '<',
			onChange: '&'
		}
	})

	.controller('SearchFilterController', [function() {
		var ctrl = this;

		var getValue = function(obj, compositeKey) {
			var keys = compositeKey.split('.');

			if (keys.length === 1) {
				return obj[keys[0]];
			}

			var iter = obj;
			keys.forEach(function(key) {
				if (angular.isDefined(iter)) {
					iter = iter[key];
				}
			});

			return iter;
		};

		var stringContains = function(src, search) {
			if (!src) {
				return false;
			}

			return src.toString().toLowerCase().indexOf(search.toLowerCase()) !== -1;
		};

		ctrl.performSearch = function() {
			if (!ctrl.search) { // catches null, undefined, ''
				ctrl.onChange({ dstModel: ctrl.model.slice() });

				return;
			}

			var searchStrings = ctrl.search.split(' ')
				.map(function(search) {
					return search.trim();
				})
				.filter(function(search) {
					return search.length > 0; // TODO: Maybe > 3?
				});

			var dstModel = ctrl.model.filter(function(element) {
				return ctrl.keys.some(function(key) {
					var value = getValue(element, key);

					// Binds the searches as "or"
					return searchStrings.some(function(search) {
						return stringContains(value, search);
					});
				});
			});

			ctrl.onChange({ dstModel: dstModel });
		};

		ctrl.clearSearch = function() {
			ctrl.search = '';

			ctrl.performSearch();
		};

		ctrl.$onChanges = function(changes) {
			if (changes.model) {
				ctrl.performSearch();
			}
		};
	}]);
app
	.component('addInputField', {
		templateUrl: 'components/input/add-input-field/add-input-field.html',
		controller: 'AddInputFieldController',
		controllerAs: 'inputCtrl',
		bindings: {
			onSubmit: '='
		}
	})

	.controller('AddInputFieldController', ['$element','$timeout', '$scope', function($element, $timeout, $scope) {
		var ctrl = this;

		ctrl.isOpen = false;

		ctrl.onFocusSelect = function() {
			$element.find('.add-button-input')
				.select();
		};

		ctrl.onBlurClose = function() {
			ctrl.isOpen = false;
		};

		ctrl.onClickPlus = function() {
			if (ctrl.isOpen) {
				if (ctrl.model && ctrl.model.length > 0) {
					ctrl.onSubmit(ctrl.model);

					ctrl.model = '';
				}

				ctrl.isOpen = false;
			} else {
				ctrl.isOpen = true;

				$timeout(function() {
					$element.find('.add-button-input')
						.focus();
				}, 0, false);
			}
		};

		$scope.$on('document-click', function($event, event) {
			var $target = $(event.target);

			if (!$target.isOrChildOf('add-input-field')) {
				$timeout(function() {
					ctrl.onBlurClose();
				}, 0);
			}
		});
	}])

	.animation('.add-button-input', ['FOLDOUT_ANIMATION_DURATION', function() {
		var DURATION = 500;
		var TARGET_WIDTH = 150;

		return {
			enter: function(element, done) {
				element
					.css('width', 0)
					.animate({
						width: TARGET_WIDTH
					}, {
						duration: DURATION,
						done: done
					});
			},

			leave: function(element, done) {
				element
					.animate({
						width: 0
					}, {
						duration: DURATION,
						done: done
					});
			}
		};
	}]);
app
	.component('dateInput', {
		templateUrl: 'components/input/date-input/date-input.html',
		controller: 'DateInputController',
		controllerAs: 'dateInputCtrl',
		bindings: {
			model: '=ngModel',
			title: '@'
		}
	})

	.controller('DateInputController', ['$scope', '$filter', function($scope, $filter) {
		var ctrl = this;

		ctrl.displayModel = '';

		ctrl.showCalendar = false;

		ctrl.onToggleCalendar = function() {
			ctrl.showCalendar = !ctrl.showCalendar;
		};

		ctrl.closeCalendar = function() {
			ctrl.showCalendar = false;
		};

		$scope.$watch('dateInputCtrl.model', function(value) {
			if (value) {
				ctrl.displayModel = $filter('date')(value);
				ctrl.closeCalendar();
			}
		});

		ctrl.$onInit = function() {
			// because of the ng-if, the init has to be done here
			// I suppose it's cleaner anyway :)
			if (angular.isUndefined(ctrl.model)) {
				ctrl.model = new Date();
			}
		};
	}]);
app
	.component('dropdownInput', {
		templateUrl: 'components/input/dropdown-input/dropdown-input.html',
		controller: 'DropdownInputController',
		controllerAs: 'inputCtrl',
		bindings: {
			model: '=ngModel',
			options: '<',
			render: '&?',
			placeholder: '@'
		}
	})
	
	.controller('DropdownInputController', ['$element', function($element) {
		var ctrl = this;

		ctrl.showFoldout = false;

		ctrl.display = '';

		ctrl.closeFoldout = function() {
			ctrl.showFoldout = false;
		};

		ctrl.onFoldoutToggle = function() {
			ctrl.showFoldout = !ctrl.showFoldout;
		};

		ctrl.onOptionSelected = function(option) {
			ctrl.model = option;

			ctrl.closeFoldout();

			$element.find('.dropdown-input')
				.removeClass('required');
		};

		ctrl.renderOption = function(option, isPlaceholderAllowed) {
			if (angular.isUndefined(option)) {
			    if (isPlaceholderAllowed) {
			        if (angular.isDefined(ctrl.placeholder)) {
                        return ctrl.placeholder;
                    } else {
                        return '-- Please select --';
                    }
			    }

			    return undefined;
			}

            if (angular.isFunction(ctrl.render)) {
                return ctrl.render({ option: option });
            }

            return option.text || '&nbsp;';
		};
	}]);
app
	.component('inputWrapper', {
		templateUrl: 'components/input/generic-input/input-wrapper.html',
		transclude: true,
		controller: 'InputWrapperController',
		controllerAs: 'inputCtrl',
		bindings: {
			title: '@',
			model: '=ngModel',
			disabled: '<?ngDisabled'
		}
	})

	.controller('InputWrapperController', ['$element', '$timeout', function($element, $timeout) {
		var ctrl = this;

		ctrl.onFocus = function() {
			// a bit of a hack to get the animation running every time
			$timeout(function() {
				$element.find('.input-wrapper')
					.addClass('focus');

				$element.find('.input-wrapper-body > *')
					.removeClass('required')
					.select();
			}, 0, false);
		};

		ctrl.onBlur = function() {
			// a bit of a hack to get the animation running every time
			$timeout(function() {
				$element.find('.input-wrapper')
					.removeClass('focus');
			}, 0, false);
		};

		ctrl.$onInit = function() {
			// inject this controller into parent scope
			$element.scope().inputCtrl = ctrl;
		};
	}]);
app
	.component('tagInput', {
		templateUrl: 'components/input/tag-input/tag-input.html',
		controller: 'TagInputController',
		controllerAs: 'inputCtrl',
		bindings: {
			title: '@',
			model: '=ngModel',
			disabled: '<?ngDisabled'
		}
	})

	.controller('TagInputController', ['$element', '$timeout', function($element, $timeout) {
		var ctrl = this;

		ctrl.tags = [];
		ctrl.inputModel = '';

		ctrl.onFocus = function() {
			// a bit of a hack to get the animation running every time
			$timeout(function() {
				$element.find('.input-wrapper')
					.addClass('focus');

				$element.find('.input-wrapper-body input')
					.removeClass('required')
					.select();
			}, 0, false);
		};

		ctrl.onBlur = function() {
			ctrl.tryToAddTag(ctrl.inputModel);

			ctrl.transferTagsToModel();

			// a bit of a hack to get the animation running every time
			$timeout(function() {
				$element.find('.input-wrapper')
					.removeClass('focus');
			}, 0, false);
		};

		ctrl.tryToAddTag = function(model) {
			var trimmed = model.trim();

			if (trimmed.length > 0 && ctrl.tags.indexOf(trimmed) === -1) {
				ctrl.tags.push(trimmed);
			}

			ctrl.inputModel = '';
		};

		ctrl.transferTagsToModel = function() {
			ctrl.model = ctrl.tags.join(',');
		};

		ctrl.onChange = function(model) {
			if (model[model.length - 1] === ' ') {
				ctrl.tryToAddTag(model);
			}
		};

		ctrl.onRemoveTag = function(idx, $event) {
			ctrl.tags.splice(idx, 1);

			ctrl.transferTagsToModel();

			$event.stopPropagation();
		};

		ctrl.$onInit = function() {
			if (ctrl.model) {
				ctrl.tags = ctrl.model.split(',').map(function(tag) {
					return tag.trim();
				});
			}
		};
	}]);
app
	.component('toggleInput', {
		templateUrl: 'components/input/toggle-input/toggle-input.html',
		controller: 'ToggleInputController',
		controllerAs: 'inputCtrl',
		bindings: {
			model: '=ngModel',
			onValue: '@?',
			offValue: '@?',
			disabled: '<ngDisabled'
		}
	})

	.controller('ToggleInputController', [function() {
		var ctrl = this;

		ctrl.values = [];
		ctrl.state = 0;

		ctrl.onToggle = function() {
			if (ctrl.disabled) {
				return;
			}

			ctrl.state = 1 - ctrl.state;
			ctrl.model = ctrl.values[ctrl.state];
		};

		ctrl.$onInit = function() {
			if (angular.isUndefined(ctrl.offValue)) {
				ctrl.offValue = false;
			}

			if (angular.isUndefined(ctrl.onValue)) {
				ctrl.onValue = true;
			}

			ctrl.values = [
				ctrl.offValue,
				ctrl.onValue
			];

			ctrl.state = ctrl.model === ctrl.onValue ? 1 : 0;
			ctrl.model = ctrl.values[ctrl.state];
		};
	}]);
app
	.component('datePicker', {
		templateUrl: 'components/input/date-input/date-picker/date-picker.html',
		transclude: true,
		controller: 'DatePickerController',
		controllerAs: 'dateCtrl',
		bindings: {
			model: '=?ngModel'
		}
	})

	.controller('DatePickerController', ['SWIPE_DIRECTION', function(SWIPE_DIRECTION) {
		var ctrl = this;

		ctrl.month = null;
		ctrl.year = null;

		ctrl.previousMonth = null;
		ctrl.nextMonth = null;

		ctrl.monthNames = [
			'January',
			'February',
			'March',
			'April',
			'Mai',
			'June',
			'Juli',
			'August',
			'September',
			'Octobre',
			'Novembre',
			'Decembre'
		];

		ctrl.getDay = function(date) {
			return date.getDate();
		};

		ctrl.getMonth = function(date) {
			return date.getMonth() + 1;
		};

		ctrl.getYear = function(date) {
			return date.getFullYear();
		};

		ctrl.onPreviousMonth = function() {
			ctrl.month -= 1;

			if (ctrl.month < 1) {
				ctrl.month = 12;
				ctrl.year -= 1;
			}

			ctrl.evalSiblingMonths();
		};

		ctrl.onNextMonth = function() {
			ctrl.month += 1;

			if (ctrl.month > 12) {
				ctrl.month = 1;
				ctrl.year += 1;
			}

			ctrl.evalSiblingMonths();
		};

		ctrl.onPreviousYear = function() {
			ctrl.year -= 1;

			ctrl.evalSiblingMonths();
		};

		ctrl.onNextYear = function() {
			ctrl.year += 1;

			ctrl.evalSiblingMonths();
		};

		ctrl.evalSiblingMonths = function() {
			if (ctrl.month === 1) {
				ctrl.previousMonth = {
					month: 12,
					year: ctrl.year - 1
				};

				ctrl.nextMonth = {
					month: 2,
					year: ctrl.year
				};
			} else if (ctrl.month === 12) {
				ctrl.previousMonth = {
					month: 11,
					year: ctrl.year
				};

				ctrl.nextMonth = {
					month: 1,
					year: ctrl.year + 1
				};
			} else {
				ctrl.previousMonth = {
					month: ctrl.month - 1,
					year: ctrl.year
				};

				ctrl.nextMonth = {
					month: ctrl.month + 1,
					year: ctrl.year
				};
			}
		};

		ctrl.onSwipeMonth = function(direction) {
			switch (direction) {
				case SWIPE_DIRECTION.RIGHT:
					ctrl.onPreviousMonth();
					break;
				case SWIPE_DIRECTION.LEFT:
					ctrl.onNextMonth();
					break;
			}
		};

		ctrl.$onInit = function() {
			if (angular.isUndefined(ctrl.model)) {
				ctrl.model = new Date();
			}

			ctrl.month = ctrl.getMonth(ctrl.model);
			ctrl.year = ctrl.getYear(ctrl.model);

			ctrl.evalSiblingMonths();
		};
	}]);
app
	.component('numberInput', {
		templateUrl: 'components/input/generic-input/number-input/number-input.html',
		bindings: {
			title: '@',
			model: '=ngModel',
			disabled: '<?ngDisabled'
		}
	})

	.directive('numberInputOnly', [function() {
		return {
			restrict: 'A',
			require: 'ngModel',
			link: function($scope, $element, $attrs, ngModel) {
				var validate = function(value) {
					if (!value) {
						value = '';
					}

					var numericOnly = value.toString().replace(/[^0-9\.]/g, '');

					var count = 0;
					return numericOnly.replace(/\./g, function(match) {
						if (count++ === 0) {
							return '.';
						} else {
							return '';
						}
					});
				};

				// gets called when model is changed from input field
				// applied to the model in the view
				ngModel.$parsers.push(function(value) {
					var cleanValue = validate(value);

					var srcElement = $element.get(0);

					var oldSelection = srcElement.selectionStart;

					$element.val(cleanValue);

					// FIXME: This will fail for type="number" (which ultimately should be used)
					srcElement.selectionStart = oldSelection;
					srcElement.selectionEnd = oldSelection;

					return cleanValue;
				});

				// gets called when model is changed from outside
				// applied to the model inside the input field
				ngModel.$formatters.push(function(value) {
					return value;
				});
			}
		};
	}]);
app
	.component('textInput', {
		templateUrl: 'components/input/generic-input/text-input/text-input.html',
		bindings: {
			title: '@',
			model: '=ngModel',
			disabled: '<?ngDisabled'
		}
	});
app
	.component('textInputBox', {
		templateUrl: 'components/input/generic-input/text-input-box/text-input-box.html',
		controller: function() {
			var ctrl = this;

			ctrl.$onInit = function() {
				if (angular.isUndefined(ctrl.rows)) {
					ctrl.rows = 3;
				}
			};
		},
		bindings: {
			title: '@',
			model: '=ngModel',
			disabled: '<?ngDisabled',
			rows: '@'
		}
	});
app
	.component('datePickerTable', {
		templateUrl: 'components/input/date-input/date-picker/date-picker-table/date-picker-table.html',
		controller: 'DatePickerTableController',
		controllerAs: 'tableCtrl',
		require: {
			dateCtrl: '^^datePicker' // DatePickerController
		},
		bindings: {
			year: '<',
			month: '<',
			model: '=?ngModel'
		}
	})

	.controller('DatePickerTableController', [function() {
		var ctrl = this;

		ctrl.calendarWeek = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];

		ctrl.calendarMonth = [
			//  1  2  3  4  5  6  7
			//  8  9 10 11 12 13 14
			// 15 16 17 18 19 20 21
			// 22 23 24 25 26 27 28
			//  x  x  x  x  x  x  x

			//  x  x  x  x  x  x  1
			//  2  3  4  5  6  7  8
			//  9 10 11 12 13 14 15
			// 16 17 18 19 20 21 22
			// 23 24 25 26 27 28 29
			// 30 31

			0, 1, 2, 3, 4, 5
		];

		ctrl.getWeekDay = function(date) {
			return (date.getDay() - 1 + 7) % 7;
		};

		ctrl.getLastOfMonth = function(year, month) { // month 1 based
			if (month === 12) {
				return new Date(year + 1, 0, 0).getDate();
			}

			return new Date(year, month, 0).getDate();
		};

		ctrl.hasRowDays = function(year, month, row) {
			return ctrl.calendarWeek.some(function(day, idx) {
				var date = ctrl.getDate(year, month, row, idx);

				return !date.isNextMonth;
			});
		};

		ctrl.isSelected = function(date) {
			return ctrl.model.getFullYear() === date.getFullYear() &&
				ctrl.model.getMonth() === date.getMonth() &&
				ctrl.model.getDate() === date.getDate();
		};

		ctrl.getDate = function(year, month, row, col) { // month 1 based
			var firstOfMonth = new Date(year, month - 1, 1);
			var firstOfMonthWeekDay = ctrl.getWeekDay(firstOfMonth);

			var lastOfMonth = ctrl.getLastOfMonth(year, month);

			var day = row * 7 - firstOfMonthWeekDay + col + 1;

			var date = new Date(year, month - 1, day);

			var result = {
				date: date
			};

			if (day <= 0) {
				result.isPreviousMonth = true;
			}

			if (day > lastOfMonth) {
				result.isNextMonth = true;
			}

			if (ctrl.isSelected(date)) {
				result.isSelected = true;
			}

			return result;
		};

		ctrl.onDateSelected = function(date) {
			ctrl.model = date;
		};

		ctrl.$onChanges = function(changes) {
			ctrl.calendarMonth = ctrl.calendarMonth.slice(); // create a clone to give it a new id, to force a re-rendering
		};

		ctrl.$onInit = function() {
			if (angular.isUndefined(ctrl.model)) {
				ctrl.model = new Date();
			}
		};
	}]);